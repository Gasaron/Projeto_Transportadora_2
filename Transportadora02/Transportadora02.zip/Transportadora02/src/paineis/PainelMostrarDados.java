package paineis;

import classes.Veiculos;

import javax.swing.*;
import java.awt.*;

public class PainelMostrarDados extends JPanel {

    private JButton jbCarro, jbOnibus, jbCaminhao;
    private JCheckBox jckBau, jckBasculante, jckCarreta;
    private JScrollPane jsMostrar;
    private List<Veiculos> veiculos = null;

    public PainelMostrarDados(List<Veiculos> veiculos) {
        super();
        setSize(400,400);
        setLayout(null);
        setBackground(Color.black);
        this.veiculos = veiculos;
        iniciarComponetes();
        criarEventos();
    }
    private void iniciarComponetes(){
//        Obj
        jbCarro = new JButton("Carro");
        jbOnibus = new JButton()"Onibus";
        jbCaminhao = new JButton("Caminhão");
        jckBasculante = new JCheckBox("Basculante");
        jckBasculante.setOpaque(false);
        jckCarreta = new JCheckBox("Carreta");
        jckBasculante.setOpaque(false);
        jtaMostrar = new JTextArea();
        jsMostrar = new JScrollPane(jtaMostrar);

//        Adc
        add(jbCarro);
        add(jbCaminhao);
        add(jbOnibus);
        add(jckBasculante);
        add(jckBau);
        add(jckMostrar);
    }
}
