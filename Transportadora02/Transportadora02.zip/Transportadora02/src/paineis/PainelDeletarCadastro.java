package paineis;

public class PainelDeletarCadastro {
}
