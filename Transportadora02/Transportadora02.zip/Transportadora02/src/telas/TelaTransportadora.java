package telas;

public class TelaTransportadora {
}
