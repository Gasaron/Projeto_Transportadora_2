package paineis;

public class List<T> {
    public String indexOf(T veiculo) {
        return null;
    }
}
